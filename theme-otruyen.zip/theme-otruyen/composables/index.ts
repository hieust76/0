import { useFetchData } from './useFetchData';

export { useFetchData };
