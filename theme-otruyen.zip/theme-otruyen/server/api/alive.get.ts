export default defineEventHandler(() => {
  return {
    alive: true,
  };
});
